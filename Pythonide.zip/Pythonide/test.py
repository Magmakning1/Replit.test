## Easy acsess variable bank ##


#Imports
import os
import sys
import pygame

